//
//  BankOfferViewController.swift
//  PaytmNativeSampleApp
//
//  Created by Nikhil Agarwal on 29/04/20.
//  Copyright © 2020 Sumit Garg. All rights reserved.
//

import UIKit

import PaytmNativeSDK

class BankOfferViewController: BaseViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}
