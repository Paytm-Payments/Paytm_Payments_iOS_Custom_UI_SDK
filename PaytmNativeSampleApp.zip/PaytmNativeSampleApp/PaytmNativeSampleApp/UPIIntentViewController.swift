//
//  UPIIntentViewController.swift
//  PaytmNativeSampleApp
//
//  Created by Aman Gupta on 25/06/21.
//  Copyright © 2021 Sumit Garg. All rights reserved.
//

import UIKit
import PaytmNativeSDK

class UPIIntentViewController: BaseViewController {
    @IBOutlet weak var gpaySwitch: UISwitch!
    @IBOutlet weak var paytmSwitch: UISwitch!
    @IBOutlet weak var phonepeSwitch: UISwitch!
    
    var selectedpayType = PspApp.paytm
    var customPolling: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func tappedOnPTC(_ sender: UIButton) {
        super.proceedPayment(sender)
    }
    
    @IBAction func gpaySwitch(_ sender: UISwitch) {
        if sender.isOn {
            gpaySwitch.isOn = true
            paytmSwitch.isOn = false
            phonepeSwitch.isOn = false
            selectedpayType = .gPay
        }
    }
    
    @IBAction func paytmSwitch(_ sender: UISwitch) {
        if sender.isOn {
            gpaySwitch.isOn = false
            paytmSwitch.isOn = true
            phonepeSwitch.isOn = false
            selectedpayType = .paytm
        }
    }
    
    @IBAction func phonePeSwitch(_ sender: UISwitch) {
        if sender.isOn {
            gpaySwitch.isOn = false
            paytmSwitch.isOn = false
            phonepeSwitch.isOn = true
            selectedpayType = .phonePe
        }
    }
    
    @IBAction func customPollSwitchTapped(_ sender: UISwitch) {
        if sender.isOn {
            customPolling = true
        } else {
            customPolling = false
        }
    }
    override func hitInitiateTransactionAPI(_ env: AIEnvironment) {
        if let childVC = self.children.first as? UINavigationController, let rootVC = childVC.viewControllers.first as? ViewController {

            //initiatee Transaction
            rootVC.initiateTransitionToken { (orderId, merchantId, txnToken, ssoToken) in
                DispatchQueue.main.async {
                    let baseUrlString = (env == .production) ? kProduction_ServerURL : kStaging_ServerURL
                    let flowType: AINativePaymentFlow = AINativePaymentFlow(rawValue: (rootVC.flowTypeSegment.titleForSegment(at: rootVC.flowTypeSegment.selectedSegmentIndex) ?? "NONE")) ?? .none
                    
                    var amount: CGFloat = 0.0
                    if let floatAmount = Double(rootVC.transactionAmount) {
                        amount = CGFloat(floatAmount)
                    }
                    
                    let urlScheme = (rootVC.urlSchemeTextField.text == "") ? "" : rootVC.urlSchemeTextField.text!
                    
                    
                   
                    self.appInvoke.callProcessTransactionAPIForUPIIntent(flowType:flowType,amount: amount, orderId: orderId, mid: merchantId, txnToken: txnToken, pspApp: "paytm", shouldShowCustomIntentPolling: false, delegate: self) { (response, error) in
                        if error != nil {
                            print(error ?? "")
                            return
                        }
                        if let response = response, let body = response["body"] as? [String: Any], let deepLinkInfo = body["deepLinkInfo"] as? [String: Any], let deepLink = deepLinkInfo["deepLink"] as? String {
                            print(deepLink)
                            let urlString = deepLink + "&source_callback=paytm12345://"
                            print(urlString)
                            if let url = URL(string: urlString), UIApplication.shared.canOpenURL(url) {
                                UIApplication.shared.open(url, options: [:], completionHandler: nil)
                                if self.customPolling {
                                    self.appInvoke.startPollingForUpiIntent(orderId: orderId, mid: merchantId, txnToken: txnToken) { (status, response, error) in
                                        var title = "Transaction Status"
                                        var message = ""
                                        if status == .success {
                                            message = "Success"
                                        } else if status == .pending {
                                            message = "Pending"
                                        } else if status == .failure {
                                            message = "Failure, " + (error ?? "")
                                        } else if let error = error {
                                            title = "Error"
                                            message = error
                                        }
                                        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
                                        alert.addAction(UIAlertAction(title: "okay", style: .default, handler: nil))
                                        self.present(alert, animated: true, completion: nil)
                                    }
                                }
                            } else {
                                let alert = UIAlertController(title: "DeepLink", message: deepLink, preferredStyle: .alert)
                                alert.addAction(UIAlertAction(title: "okay", style: .default, handler: nil))
                                self.present(alert, animated: true, completion: nil)
                            }
                        } else {
                            let alert = UIAlertController(title: "Response", message: (response?.isEmpty ?? false) ? (error ?? nil) : String(describing: response), preferredStyle: .alert)
                            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                    }
                }
            }
        }
    }
}
